import android.os.Bundle;

import androidx.fragment.app.Fragment;

import com.professionalandroid.apps.earthquake.Earthquake;

import java.util.ArrayList;

public class EarthquakeListFragment extends Fragment {
    private ArrayList<Earthquake> mEarthquekes = new ArrayList<Earthquake>();

    public EarthquakeListFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
