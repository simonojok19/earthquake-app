package com.professionalandroid.apps.earthquake;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EarthquakeMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
